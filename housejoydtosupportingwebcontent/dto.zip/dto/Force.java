package com.ts.housejoy.dto;

import java.util.List;

public class Force extends User{
	
	private String aadharImage;	
				
	public String getAadharImage() {
		return aadharImage;
	}

	public void setAadharImage(String aadharImage) {
		this.aadharImage = aadharImage;
	}			
}
